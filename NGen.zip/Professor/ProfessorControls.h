#ifndef PROFESSORCONTROLS_H
#define PROFESSORCONTROLS_H

#define PROF_OGL_MAJOR				4
#define PROF_OGL_MINOR				3

//Max physics timestep in seconds
#define PROF_MAX_PHYSICS_TIMESTEP 		0.005f
//Minimum number of times to force physics to update per frame
#define PROF_MIN_PHYSICS_STEPS_PER_FRAME 	50
//The framerate in miliseconds
#define PROF_FRAMERATE				64

//The global acceleration due to gravity in m/s^2
#define PROF_GRAVITY				-9.8f

//Camera speed
#define PROF_CAM_SPEED				10.0f
#define PROF_CAM_ANGULAR_SPEED			0.01f

//Maximum scene luminence
#define PROF_L_MAX				10.0f

//Background color
#define PROF_BACKGROUND_R			0.0f
#define PROF_BACKGROUND_G			0.0f
#define PROF_BACKGROUND_B			0.0f

#endif
