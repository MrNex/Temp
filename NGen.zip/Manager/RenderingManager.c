#if defined __linux__

//Enable POSIX definitions (for timespec)
#if __STDC_VERSION__ >= 199901L
#define _XOPEN_SOURCE 600
#else
#define _XOPEN_SOURCE 500
#endif
//#define _POSIX_C_SOURCE 1

#include <time.h>

#endif 

#include "RenderingManager.h"


#include <stdio.h>

#include "AssetManager.h"
#include "TimeManager.h"

#include "../Render/RayTracerRenderPipeline.h"

///
//Internals
RenderingBuffer* renderingBuffer;

///
//Static Declarations

///
//Allocates memory for a rendering buffer
//
//Returns:
//	Pointer to a newly allocated rendering buffer
static RenderingBuffer* RenderingManager_AllocateBuffer(void);

///
//Initializes a rendering buffer
//
//Parameters:
//      buffer: Rendering buffer to initialize
static void RenderingManager_InitializeBuffer(RenderingBuffer* buffer);

///
//Frees the memory consumed by a Rendering Buffer
//
//Parameters:
//      buffer: The buffer to free
static void RenderingManager_FreeBuffer(RenderingBuffer* buffer);

///
//External functions

///
//Initialize the Rendering Manager
void RenderingManager_Initialize(void)
{
	//Enable Rendering Tests
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);


	renderingBuffer = RenderingManager_AllocateBuffer();
	RenderingManager_InitializeBuffer(renderingBuffer);

	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glPointSize(2.0f);
	glLineWidth(2.0f);

	int numAttachments;
	glGetIntegerv(GL_MAX_COLOR_ATTACHMENTS, &numAttachments);

	printf("\nThere are %d allowed attachments", numAttachments); 
}

///
//Frees resources taken up by the RenderingManager
void RenderingManager_Free(void)
{
	RenderingManager_FreeBuffer(renderingBuffer);
}

///
//Gets the Rendering Manager's internal Rendering Buffer
//
//Returns:
//	RenderingManager's internal Rendering Buffer
RenderingBuffer* RenderingManager_GetRenderingBuffer()
{
	return renderingBuffer;
}

///
//Renders a memory pool of objects with the active rendering pipeline
//Skips gameobjects which are uninitialized or do not have a mesh
//
//Parameters:
//	memoryPool: A pointer to the memory pool of game objects to render
void RenderingManager_Render(MemoryPool* memoryPool)
{
	//Update the camera's view matrix
	Camera_UpdateViewMatrix(renderingBuffer->camera);

	renderingBuffer->renderPipelines[RenderingManager_Pipeline_RAYTRACER]->Render
	(
		renderingBuffer->renderPipelines[RenderingManager_Pipeline_RAYTRACER],
		renderingBuffer,
		memoryPool
	);

}


///
//Allocates memory for a rendering buffer
//
//Returns:
//	Pointer to a newly allocated rendering buffer
static RenderingBuffer* RenderingManager_AllocateBuffer(void)
{
	RenderingBuffer* buffer = (RenderingBuffer*)malloc(sizeof(RenderingBuffer));
	return buffer;
}

///
//Initializes a rendering buffer
//
//Parameters:
//      buffer: Rendering buffer to initialize
static void RenderingManager_InitializeBuffer(RenderingBuffer* buffer)
{
	//Shaders
	//buffer->shaderPrograms = (ShaderProgram**)malloc(sizeof(ShaderProgram*));
	buffer->renderPipelines[RenderingManager_Pipeline_RAYTRACER] = RenderPipeline_Allocate();
	RayTracerRenderPipeline_Initialize(buffer->renderPipelines[RenderingManager_Pipeline_RAYTRACER]);


	//Camera
	buffer->camera = Camera_Allocate();
	Camera_Initialize(buffer->camera);

	//Lighting
	buffer->directionalLightVector = Vector_Allocate();
	Vector_Initialize(buffer->directionalLightVector, 3);
	buffer->directionalLightVector->components[2] = -1.0f;
	buffer->directionalLightVector->components[1] = -0.25;

	Vector_Normalize(buffer->directionalLightVector);
	
	Vector lightColor;
	Vector_INIT_ON_STACK(lightColor, 3);

	lightColor.components[0] = lightColor.components[1] = lightColor.components[2] = 1.0f;
	
	buffer->directionalLight = DirectionalLight_Allocate();
	DirectionalLight_Initialize(buffer->directionalLight, &lightColor, (Vector*)&Vector_ZERO, 0.2f, 1.0f);




	//Debug
	buffer->debugOctTree = 0;
}

///
//Frees the memory consumed by a Rendering Buffer
//
//Parameters:
//      buffer: The buffer to free
static void RenderingManager_FreeBuffer(RenderingBuffer* buffer)
{
	for(int i = RenderingManager_Pipeline_RAYTRACER; i < RenderingManager_Pipeline_NUMPIPELINES; ++i)
	{
		RenderPipeline_Free(buffer->renderPipelines[i]);
	}
	Camera_Free(buffer->camera);
	Vector_Free(buffer->directionalLightVector);
	DirectionalLight_Free(buffer->directionalLight);
	free(buffer);
}
