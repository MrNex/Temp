#ifndef RENDERINGMANAGER_H
#define RENDERINGMANAGER_H

#include <GL/glew.h>
#include <GL/freeglut.h>

#include "ObjectManager.h"

#include "../Render/RenderPipeline.h"
#include "../Render/Camera.h"
#include "../Render/DirectionalLight.h"

#include "../GObject/GObject.h"

#include "../Data/LinkedList.h"

enum RenderingManager_Pipeline
{
	RenderingManager_Pipeline_FORWARD,
	RenderingManager_Pipeline_DEFERRED,
	RenderingManager_Pipeline_RAYTRACER,
	RenderingManager_Pipeline_NUMPIPELINES
};

typedef struct RenderingBuffer
{
	RenderPipeline* renderPipelines[RenderingManager_Pipeline_NUMPIPELINES];
	Camera* camera;
	Vector* directionalLightVector;
	DirectionalLight* directionalLight;
	unsigned char debugOctTree;
} RenderingBuffer;

//Internals
extern RenderingBuffer* renderingBuffer;

//Functions

///
//Initialize the Rendering Manager
void RenderingManager_Initialize(void);

///
//Frees resources taken up by the RenderingManager
void RenderingManager_Free(void);

///
//Assigns the attributes of the active camera to the necessary shader program uniforms
void RenderingManager_SetCameraUniforms(void);
///
//Renders a memory pool of objects with the active rendering pipeline
//Skips gameobjects which are uninitialized or do not have a mesh
//
//Parameters:
//	memoryPool: A pointer to the memory pool of game objects to render
void RenderingManager_Render(MemoryPool* memoryPool);

///
//Gets the Rendering Manager's internal Rendering Buffer
//
//Returns:
//	RenderingManager's internal Rendering Buffer
RenderingBuffer* RenderingManager_GetRenderingBuffer();
#endif
