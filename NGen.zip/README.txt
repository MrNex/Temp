Author: Nicholas Gallagher
Project: Real Time Ray Tracing in a Game Engine

-------------
Authors Notes:
-------------

A few disclaimers:
	This project has a ton of technical debt. I tried to provide a stripped down version, but it is still monstrous with a lot of old code and poor decisions that seemed like a good idea at the time.
	
	Some things you might notice: The physics (especially collisions between spheres and convex polyhedra or oriented boxes) can get wonky, especially if the physics engine is not getting enough attention.
	The simulation will slow down when more things are in constant contact with one another. The change in timestep length can occasionally cause some weirdness.

	I haven't put in sane controls for tone reproduction yet, because I was trying to figure out what was wrong with my implementation. Turns out, nothing was wrong. My background color of black drastically skews the results. Note the extreme change in tone if you look straight at the floor and allow no black pixels on the screen! Because of the overwhelming amount of black that is usually on the screen, I've hardcoded the ward tone reproduction model to simulate a maximum luminance value of 10 nits. This helps tone down the brightness of the scene due to the background.

	The ray tracer code can be found in Kernel/RayTracerKernelProgram.cl.
	Illumination code can be found in Kernel/Illumination.cl
	Tone reproduction code can be found in Kernel/ToneReproduction.cl

	The tone reproduction operator can be changed in Kernel/ToneReproduction.cl lines 229-230
	The tone reproduction arguments can be changed in Device/ToneReproductionKernelProgram.c lines 161-162

	The "Scene description" is done in Implementation/Implementation.c should you want to alter the scene / object properties.

-------------
Dependencies:
-------------
OpenGL 4.3
	glew 1.13.0-1		http://glew.sourceforge.net/
	freeglut 3.0.0-1	http://freeglut.sourceforge.net/

OpenCL 2.1


-------------
Installation:
-------------
1)	Navigate to the directory containing the unzipped files

2)	Make a directory called "Bin"
		mkdir Bin

3)	Inside of the new Bin directory, make a directory called "State"
		mkdir Bin/State

4)	Utilize make to compile the project
		make

-------------
Removal:
-------------
1)	Utilize make to clean project
		make clean
2)	Recursively remove Bin directory
		rm -r Bin


-------------
Running:
-------------
1)	After a successful installation, simply run the compiled program from the installation directory
		./NGen

-------------
In-App Controls:
-------------

	m - Locks the mouse to allow for user interaction
	q - Unlocks mouse

The following controls will only work when the mouse is locked:

	escape - Quits the NGen
	
	w - Move camera forward
	a - Move camera left
	s - Move camera backward
	d - Move camera right

	mouse movement - Rotate camera
	left mouse button - Shoot

-------------
Programmatic Controls:
-------------

	I've provided a file containing several definitions which can be altered to make the program more suitable for a given environment.
	The file can be found:
		Professor/ProfessorControls.h
	
	After changing the contents of the file, the program must be recompiled.
	A short summary of each control:

		PROF_OGL_MAJOR - 
			The major version of the openGL context to try to create

		PROF_OGL_MINOR -
			The minor version of the openGL context to try to create
	
		PROF_MAX_PHYSICS_TIMESTEP - 
			Controls the maximum allowed timestep between updates of the physics engine.
			If any additional time occurs, it will be lost and the physics engine will fail to run in real time.

		PROF_MIN_PHYSICS_STEPS_PER_FRAME - 
			Controls the amount of forced physics engine updates before re-checking if rendering must occur.
			A higher value contributes to a more stable simulation.
			Too high a value will cause the physics engine to starve the rendering pipeline of CPU cycles.

		PROF_FRAMERATE - 
			Controls the framerate of the simulation

		PROF_GRAVITY - 
			Controls the gravity of the simulation.
			Setting this to 0.0f and not shooting anything will allow you to view the static scene

		PROF_CAM_SPEED -
			The linear speed of the camera

		PROF_CAM_ANGULAR_SPEED - 
			The angular speed of the camera



