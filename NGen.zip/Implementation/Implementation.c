#include "Implementation.h"

#include "../State/FirstPersonCamera.h"
#include "../State/Shoot.h"

#include "../Professor/ProfessorControls.h"


///
//Initializes the scene within the engine.
//This must be done after all engine components are initialized.
void InitializeScene(void)
{

	State* state;

	///
	//Camera controller simulation
	unsigned int camID = GObject_Request();
	GObject* cam = ObjectManager_LookupObject(camID);
	GObject_Initialize(cam);

	state = State_Allocate();

	State_FirstPersonCamera_Initialize(state, PROF_CAM_SPEED, PROF_CAM_ANGULAR_SPEED, 0.05f);

	GObject_AddState(cam,state);

	state = State_Allocate();
	State_Shoot_Initialize(state, 5.0f, 5.0f, 0);
	GObject_AddState(cam, state);
	
	//Set directional light direction
	DirectionalLight* l = RenderingManager_GetRenderingBuffer()->directionalLight;
	l->direction->components[1] = -1.0f;
	l->direction->components[2] = -0.3f;
	l->direction->components[0] = -1.0f;

	Vector_Normalize(l->direction);


	l->base->ambientIntensity = 0.001f;
	l->base->diffuseIntensity = 0.3f;

	//Create floor
	unsigned int blockID = GObject_Request();
	GObject* block = ObjectManager_LookupObject(blockID);
	GObject_Initialize(block);

	//Mesh & Material
	block->mesh = AssetManager_LookupMesh("Cube");
	block->materialID = Material_Allocate();
	GLuint texID = AssetManager_LookupTextureID("Wood");
	Material_Initialize(block->materialID, texID);

	Material* material = MemoryPool_RequestAddress(assetBuffer->materialPool, block->materialID);
	material->tile[0] = 2.0f;
	material->tile[1] = 3.0f;
	material->specularCoefficient = 0.0f;
	material->specularPower = 32.0f;
	material->ambientCoefficient = 0.2f;
	material->reflectedCoefficient = 0.0f;
	material->transmittedCoefficient = 0.0f;
	material->localCoefficient = 1.0f;

	//Floor collider
	block->collider = Collider_Allocate();

	float min[3] = { -1.0f, -1.0f, -1.0f };
	float max[3] = {1.0f, 1.0f, 1.0f};
	AABBCollider_Initialize(block->collider, min, max);

	//Floor rigid body
	block->body = RigidBody_Allocate();
	RigidBody_Initialize(block->body, block->frameOfReference, 0.0f);
	block->body->freezeTranslation = block->body->freezeRotation = 1;
	block->body->dynamicFriction = block->body->staticFriction = 0.5f;
	block->body->rollingResistance = 0.0f;

	//Floor scale and position
	Vector v;
	Vector_INIT_ON_STACK(v, 3);
	v.components[0] = 20.0f;
	v.components[2] = 30.0f;
	v.components[1] = 1.0f;

	GObject_Scale(block, &v);

	Vector_Copy(&v, &Vector_ZERO);
	v.components[0] = -14.0f;
	v.components[1] = -5.5f;
	v.components[2] = -20.0f;

	GObject_Translate(block, &v);

	ObjectManager_RegisterObject(blockID);
	
	//Create transmissive Large sphere
	blockID = GObject_Request();
	block = ObjectManager_LookupObject(blockID);
	GObject_Initialize(block);

	//Transmissive sphere Mesh & Material
	block->mesh = AssetManager_LookupMesh("Sphere");
	block->materialID = Material_Allocate();
	Material_Initialize(block->materialID, AssetManager_LookupTextureID("White"));
	material = MemoryPool_RequestAddress(assetBuffer->materialPool, block->materialID);

	material->specularCoefficient = 1.0f;
	material->specularPower = 20.0f;
	material->diffuseCoefficient = 0.0075f;
	material->ambientCoefficient = 0.0075f;
	material->localCoefficient = 0.1f;
	material->reflectedCoefficient = 0.001f;
	material->transmittedCoefficient = 0.8f;
	material->indexOfRefraction = 0.95f;

	//Transmissive sphere collider
	block->collider = Collider_Allocate();
	SphereCollider_Initialize(block->collider, 1.0f, &Vector_ZERO);


	//Transmissive sphere rigid body
	block->body = RigidBody_Allocate();
	RigidBody_Initialize(block->body, block->frameOfReference, 2.0f);
	block->body->dynamicFriction = block->body->staticFriction = 0.1f;
	block->body->coefficientOfRestitution = 1.0f;
	block->body->rollingResistance = 0.1f;

	//Transmissive sphere position & Scale
	Vector_Copy(&v, &Vector_ZERO);
	v.components[0] = 0.0f;
	v.components[1] = 0.0f;
	v.components[2] = -6.0f;

	GObject_Translate(block, &v);

	Vector_Copy(&v, &Vector_ZERO);
	v.components[0] = v.components[1] = v.components[2] = 2.0f;
	GObject_Scale(block, &v);

	ObjectManager_RegisterObject(blockID);
	
	//Create small reflective sphere
	blockID = GObject_Request();
	block = ObjectManager_LookupObject(blockID);
	GObject_Initialize(block);

	//Reflective sphere mesh & material
	block->mesh = AssetManager_LookupMesh("Sphere");
	block->materialID = Material_Allocate();
	unsigned int temp = AssetManager_LookupTextureID("Concrete");
	Material_Initialize(block->materialID, temp);

	material = MemoryPool_RequestAddress(assetBuffer->materialPool, block->materialID);
	material->specularPower = 20.0f;
	material->ambientCoefficient = 0.15f;
	material->diffuseCoefficient = 0.25f;
	material->specularCoefficient = 1.0f;
	material->localCoefficient = 0.5f;
	material->reflectedCoefficient = 0.75f;
	material->transmittedCoefficient = 0.0f;

	//Reflective sphere collider
	block->collider = Collider_Allocate();
	SphereCollider_Initialize(block->collider, 1.0f, &Vector_ZERO);

	//Reflective sphere rigid body	
	block->body = RigidBody_Allocate();
	RigidBody_Initialize(block->body, block->frameOfReference, 1.0f);
	block->body->dynamicFriction = block->body->staticFriction = 0.08f;
	
	block->body->coefficientOfRestitution = 0.8f;
	block->body->rollingResistance = 0.1f;

	//Reflective sphere position and scale	
	Vector_Copy(&v, &Vector_ZERO);
	v.components[0] = -3.8f;
	v.components[1] = -2.0f;
	v.components[2] = -8.0f;

	GObject_Translate(block, &v);

	Vector_Copy(&v, &Vector_ZERO);
	v.components[0] = v.components[1] = v.components[2] = 1.8f;
	GObject_Scale(block, &v);
	ObjectManager_RegisterObject(blockID);

	//Set gravity
	Vector* gravity = Vector_Allocate();
	Vector_Initialize(gravity, 3);
	gravity->components[1] = PROF_GRAVITY;
	
	PhysicsManager_AddGlobalAcceleration(gravity);	
}
